/*******************************************************************************
 * @file  FileList.java
 *
 * @author   John Miller
 */

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
 
 /*******************************************************************************
  * This class allows data tuples/tuples (e.g., those making up a relational table)
  * to be stored in a random access file.  This implementation requires that each
  * tuple be packed into a fixed length byte array.
  */
public class FileList extends AbstractList<Comparable[]> implements List<Comparable[]>, Serializable, RandomAccess {
    /** File extension for data files.
     */
    private static final String EXT = ".dat";

    /** The random access file that holds the tuples.
     */
    private RandomAccessFile file;

    /** The name of table.
     */
    private final String tableName;

    /** The number bytes required to store a "packed tuple"/record.
     */
    private final int recordSize;

    /** Counter for the number of tuples in this list.
     */
    private int nRecords = 0;

    /***************************************************************************
     * Construct a FileList.
     * @param _tableName   the name of the table
     * @param _recordSize  the size of tuple in bytes.
     */
    public FileList(String _tableName, int _recordSize) {
        tableName = _tableName;
        recordSize = _recordSize;

        try {
            file = new RandomAccessFile(tableName + EXT, "rw");
        } catch (FileNotFoundException ex) {
            file = null;
            System.out.println("FileList.constructor: unable to open - " + ex);
        }
    }

    /***************************************************************************
     * Add a new tuple into the file list by packing it into a record and writing
     * this record to the random access file.  Write the record either at the
     * end-of-file or into a empty slot.
     * @param tuple  the tuple to add
     * @return  whether the addition succeeded
     * 
     * @author : Bandi, Purna Sai Kalyan Reddy
     */
    @Override
    public boolean add(Comparable[] tuple) {
        byte[] record = pack(tuple);

        if (record.length != recordSize) {
            System.out.println("FileList.add: wrong record size " + record.length);
            return false;
        }
        try {
            file.seek(file.length()); // Ensure we write at the end of the file
            file.write(record);
        } catch (IOException e) {
            System.out.println("FileList.add: write failed");
            return false;
        }
        nRecords++;
        return true;
    }

    /***************************************************************************
     * Get the ith tuple by seeking to the correct file position and reading the
     * record.
     * @param i  the index of the tuple to get
     * @return  the ith tuple
     * 
     * @author : Bandi, Purna Sai Kalyan Reddy
     */
    @Override
    public Comparable[] get(int i) {
        byte[] record = new byte[recordSize];

        try {
            file.seek(i * recordSize);
            file.readFully(record); // Use readFully to ensure the entire record is read
        } catch (IOException e) {
            System.out.println("FileList.get: seek/read failed");
            return null;
        }

        return unpack(record); // Use unpack method
    }

    /***************************************************************************
     * Return the size of the file list in terms of the number of tuples/records.
     * @return  the number of tuples
     */
    @Override
    public int size() {
        return nRecords;
    }

    /***************************************************************************
     * Close the file.
     */
    public void close() {
        try {
            file.close();
        } catch (IOException ex) {
            System.out.println("FileList.close: unable to close - " + ex);
        }
    }

    // Unsupported operations
    @Override
    public Comparable[] set(int index, Comparable[] element) {
        throw new UnsupportedOperationException("Set operation is not supported.");
    }

    @Override
    public void add(int index, Comparable[] element) {
        throw new UnsupportedOperationException("Add operation is not supported.");
    }

    @Override
    public Comparable[] remove(int index) {
        throw new UnsupportedOperationException("Remove operation is not supported.");
    }

    /**
     * Packs a record into bytes for writing to the file.
     * @param tuple The record to pack.
     * @return The packed record as bytes.
     */
    private byte[] pack(Comparable[] tuple) {
        StringBuilder sb = new StringBuilder();
        for (Comparable field : tuple) {
            String strField = field.toString();
            sb.append(String.format("%-10s", strField)); // Pad each field to 10 characters
        }
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    /**
     * Unpacks a record from bytes read from the file.
     * @param record The packed record.
     * @return The unpacked record.
     */
    private Comparable[] unpack(byte[] record) {
        String recordStr = new String(record, StandardCharsets.UTF_8).trim(); // Trim to remove padding
        int fieldLength = 10; // Adjust based on actual field length
        int nFields = recordSize / fieldLength;
        Comparable[] tuple = new Comparable[nFields];
        for (int i = 0; i < nFields; i++) {
            int start = i * fieldLength;
            int end = Math.min(start + fieldLength, recordStr.length());
            String field = recordStr.substring(start, end).trim(); // Trim each field
            tuple[i] = field; // Assuming field is a String
        }
        return tuple;
    }
}
