/*****************************************************************************************
 * @file  TestTupleGenerator.java
 *
 * @author   Sadiq Charaniya, John Miller
 */

 import java.io.File;
 import java.io.FileWriter;
 import java.io.IOException;
 import java.text.DecimalFormat;
 import java.util.Random;

import static java.lang.StringTemplate.STR;
import static java.lang.System.out;
 
 /*****************************************************************************************
  * This class tests the TupleGenerator on the Student Registration Database defined in the
  * Kifer, Bernstein and Lewis 2006 database textbook (see figure 3.6).  The primary keys
  * (see figure 3.6) and foreign keys (see example 3.2.2) are as given in the textbook.
  */
 public class TestTupleGenerator
 {
     /*************************************************************************************
      * The main method is the driver for TestGenerator.
      * @param args  the command-line arguments
      */
     public static void main (String [] args) throws IOException {
         // indexSelect, nonIndexSelect, indexJoin, nonIndexJoin
         String testType = "indexSelect";
         double sum = 0;
         int[] rowCounter = { 10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000};
 
         var filename = "performance.txt";
         File performanceOutput = new File(filename);
         FileWriter performanceWriter;
         try {
             performanceWriter = new FileWriter(filename);
         } catch (IOException e) {
             throw new RuntimeException(e);
         }
 
         var collate_db = new TupleGeneratorImpl ();
 
         long countStudents = 0l;
         long countProfessors = 0l;
         long countCourses = 0l;
         long countTranscripts = 0l;
         long countTeachings = 0l;
 
         for(int i = 0; i < rowCounter.length; i++) {
             out.println(STR."Evaluating performance for size: \{rowCounter[i]}");
             collate_db.addRelSchema ("Student",
                     "id name address status",
                     "Integer String String String",
                     "id",
                     null);
 
             Table Student = new Table("Student", "id name address status", "Integer String String String", "id");
 
             collate_db.addRelSchema ("Professor",
                     "id name deptId",
                     "Integer String String",
                     "id",
                     null);
 
             Table Professor = new Table("Professor", "id name deptId", "Integer String String", "id");
 
             collate_db.addRelSchema ("Course",
                     "crsCode deptId crsName descr",
                     "String String String String",
                     "crsCode",
                     null);
 
             Table Course = new Table("Course", "crsCode deptId crsName descr", "Integer String String String", "crsCode");
 
             collate_db.addRelSchema ("Teaching",
                     "crsCode semester profId",
                     "String String Integer",
                     "crcCode semester",
                     new String [][] {{ "profId", "Professor", "id" },
                             { "crsCode", "Course", "crsCode" }});
             Table Teaching = new Table("Teaching", "crsCode semester profId", "Integer Integer Integer", "crsCode semester");
 
             collate_db.addRelSchema ("Transcript",
                     "studId crsCode semester grade",
                     "Integer String String String",
                     "studId crsCode semester",
                     new String [][] {{ "studId", "Student", "id"},
                             { "crsCode", "Course", "crsCode" },
                             { "crsCode semester", "Teaching", "crsCode semester" }});
             Table Transcript = new Table("Transcript", "studId crsCode semester grade", "Integer Integer Integer String", "studId crsCode semester");
 
             var tups   = new int [] { 10000, 1000, 2000, 50000, 5000 };
 
             var resultTest = collate_db.generate(tups);
 
             for (var j = 0; j < resultTest[0].length; j++) {
                 int length = resultTest[0][j].length;
                 String col[] = new String[length];
                 for (var k = 0; k < resultTest[0][j].length; k++) {
                     col[k] = (resultTest[0][j][k]).toString();
                     countStudents++;
                 } // for
                 Comparable[] studentTuple = { col[0], col[1], col[2], col[3] };
                 Student.insert(studentTuple);
             }
 
             for (var j = 0; j < resultTest[1].length; j++) {
                 int length = resultTest[1][j].length;
                 String col[] = new String[length];
                 for (var k = 0; k < resultTest[1][j].length; k++) {
                     col[k] = (resultTest[1][j][k]).toString();
                     countProfessors++;
                 } // for
                 Comparable[] professorTuple = { col[0], col[1], col[2] };
                 Professor.insert(professorTuple);
             }
 
             for (var j = 0; j < resultTest[2].length; j++) {
                 int length = resultTest[2][j].length;
                 String col[] = new String[length];
                 for (var k = 0; k < resultTest[2][j].length; k++) {
                     col[k] = (resultTest[2][j][k]).toString();
                     countCourses++;
                 } // for
                 Comparable[] courseTuple = { col[0], col[1], col[2], col[3] };
                 Course.insert(courseTuple);
             }
 
             for (var j = 0; j < resultTest[3].length; j++) {
                 int length = resultTest[3][j].length;
                 String col[] = new String[length];
                 for (var k = 0; k < resultTest[3][j].length; k++) {
                     col[k] = (resultTest[3][j][k]).toString();
                     countTeachings++;
                 } // for
                 Comparable[] teachingTuple = { col[0], col[1], col[2] };
                 Teaching.insert(teachingTuple);
             }
 
             for (var j = 0; j < resultTest[4].length; j++) {
                 int length = resultTest[4][j].length;
                 String col[] = new String[length];
                 for (var k = 0; k < resultTest[4][j].length; k++) {
                     col[k] = (resultTest[4][j][k]).toString();
                     countTranscripts++;
                 } // for
                 Comparable[] transcriptTuple = { col[0], col[1], col[2], col[3] };
                 Transcript.insert(transcriptTuple);
             }
 
             var random = new Random();
             long endTime;
             long startTime;
             double duration;
             DecimalFormat df = new DecimalFormat("#.#############");
 
             var query = String.valueOf(resultTest[0][random.nextInt(tups[0])][0]);
 
             switch (testType) {
                 case "nonIndexSelect":
                     startTime = System.nanoTime();
                     Student.nonIndexSelect(new KeyType(query));
                     endTime = System.nanoTime();
                     duration = (double) (endTime - startTime) / 1e6;
                     sum += duration;
                     out.println(STR."Non Index Select for query: \{query}");
                     out.println(STR."Time Duration: \{df.format(duration)}ms");
                     performanceWriter.write("Non indexed Select on Student " + rowCounter[i]+  " " + String.valueOf(df.format(duration)) + "ms\n");
                     break;
                 case "nonIndexJoin":
                     startTime = System.nanoTime();
                     Student.join("id", "studId", Transcript);
                     endTime = System.nanoTime();
                     duration = (double) (endTime - startTime) / 1e6;
                     sum += duration;
                     out.println(STR."Non Index Join for query: \{query}");
                     out.println(STR."Time Duration: \{df.format(duration)}ms");
                     performanceWriter.write("Non indexed Join on Student-Transcript " + rowCounter[i] +  " " + String.valueOf(df.format(duration)) + "ms\n");
                     break;
                 case "indexSelect":
                     startTime = System.nanoTime();
                     Course.select(new KeyType(query));
                     endTime = System.nanoTime();
                     duration = (double) (endTime - startTime) / 1e6;
                     sum += duration;
                     out.println(STR."Index Select for query: \{query}");
                     out.println(STR."Time Duration: \{df.format(duration)}ms");
                     performanceWriter.write("Indexed Select on Course " + rowCounter[i] +  " " + String.valueOf(df.format(duration)) + "ms\n");
                     break;
                 case "indexJoin":
                     startTime = System.nanoTime();
                     Professor.i_join("id", "profId", Teaching);
                     endTime = System.nanoTime();
                     duration = (double) (endTime - startTime) / 1e6;
                     sum += duration;
                     out.println(STR."Index Join for query: \{query}");
                     out.println(STR."Time Duration: \{df.format(duration)}ms");
                     performanceWriter.write("Indexed Join on Professor-Teaching: " + rowCounter[i] +  " " + String.valueOf(df.format(duration)) + "ms\n");
                     break;
                 default:
                     out.println("Please check the type indexSelect, nonIndexSelect, indexJoin, nonIndexJoin");
             }
 
         } // main
         performanceWriter.write("Average: " + String.valueOf(sum/rowCounter.length) + "ms\n");
         try {
             performanceWriter.close();
         } catch (IOException e) {
             throw new RuntimeException(e);
         }
     }
 } // TestTupleGenerator 